
from typing import TypedDict, List


class AgentState(TypedDict):

    query: str

    route: str

    context: List[str]

    answer: str
